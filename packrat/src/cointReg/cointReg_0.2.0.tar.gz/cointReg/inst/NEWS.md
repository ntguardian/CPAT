# cointReg 0.2 (2016-06-14)
 * Change generation of the "vu" part of Omega/Delta/Sigma in `cointRegFM` and
   `cointRegD`, because Delta is not a symmetric matrix in general.
 * Fix some formats and links.

# cointReg 0.1 (2016-06-03)
 * First CRAN release version of the package.
